<p>Jaką kwotą dysponujesz</p>
<form action="" method="post">
<input type="number" placeholder="kwota zł" name="kwota"> zł

    <input type="submit" value="wypisz dostępne dania">
    </form>
<?php
if(isset($_POST['kwota']))
{
    $kwota=$_POST['kwota'];
    $connect=mysqli_connect("localhost","root","","dane");
    $zapytanie="SELECT `nazwa` FROM `dania` WHERE `cena` <= '$kwota' ORDER BY `cena` DESC ";
    $wynik=mysqli_query($connect,$zapytanie);
   echo "<ul>"; while($rekord=mysqli_fetch_array($wynik))
    {
        echo "<li>$rekord[0]</li>";
    }
     echo "</ul>"; 
    mysqli_close($connect);
    //header("location:dania.php");
}
?>