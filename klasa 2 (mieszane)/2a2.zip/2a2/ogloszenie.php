<form action="" method="post">
    Podaj tytuł ogłoszenia
    <input type="text" name="tytul"><br>
    Podaj treść ogloszenia
    <textarea name="tresc" cols="40" rows="10">
    </textarea><br>
    Podaj id użytkownika
    <select name="uzytkownik">
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    </select>
    <input type="submit" value="wstaw do bazy">
</form>
<?php
if(isset($_POST['tytul']) && !empty($_POST['tresc']) && isset($_POST['uzytkownik']))
{
    $tytul=$_POST['tytul'];
    $tresc=$_POST['tresc'];
    $id_u=$_POST['uzytkownik'];
    //echo $tytul;
    $connect=mysqli_connect("localhost","root","","baza");
    if($connect)
    {
        //echo"połąćzono";
        $zapytanie="INSERT INTO `ogloszenie` (`id`, `uzytkownik_id`, `kategoria`, `podkategoria`, `tytul`, `tresc`) VALUES (NULL, '$id_u', '1', '1', '$tytul', '$tresc');";
        mysqli_query($connect,$zapytanie);
    }
    mysqli_close($connect);
    header("location:ogloszenie.php");
}

?>