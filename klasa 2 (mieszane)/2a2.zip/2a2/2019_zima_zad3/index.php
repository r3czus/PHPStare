<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Filmoteka</title>
    <link rel="stylesheet" href="styl3.css">
    </head>
<body>
    <div class="gora">
    <img src="klaps.png" alt="Nasze filmy">
    </div>
    <div class="gora">
    <h1>BAZA FILMÓW</h1>
    </div>
    <div class="gora">
    <form action="" method="post">
        <select name="gatunki">
        <option value="1">Sci-Fi</option>
        <option value="2">animacja</option>
        <option value="3">dramat</option>
        <option value="4">horror</option>
        <option value="5">komedia</option>
        </select>
        <input type="submit" value="Filmy">
        </form>
    </div>
    <div class="gora">
    <img src="gwiezdneWojny.jpg" alt="szturmowcy">
    </div>
    <div class="glowny">
    <h2>Wybrano filmy</h2>
        <?php
$connect=mysqli_connect("localhost","root","","dane");
    if (isset($_POST['gatunki']))
    {
        $gat=$_POST['gatunki'];
        //echo "wybrano $gat";
$zapytanie="SELECT `tytul`, `rok`, `ocena` FROM `filmy` WHERE `gatunki_id` = $gat";
$wynik=mysqli_query($connect,$zapytanie);
while($rekord=mysqli_fetch_array($wynik))
{
    echo "<p>Tytuł: $rekord[0], Rok produkcji: $rekord[1],Ocena: $rekord[2]</p>";
}
    }
mysqli_close($connect);
        ?>
       
 
    </div>
    <div class="glowny">
    <h2>Wszystkie filmy</h2>
        <?php
        $connect=mysqli_connect("localhost","root","","dane");
        
        $zapytanie2="SELECT filmy.id,tytul,`imie`, `nazwisko` FROM `rezyserzy`,filmy WHERE filmy.rezyserzy_id=rezyserzy.id";
        $wynik=mysqli_query($connect,$zapytanie2);
        while($rekord=mysqli_fetch_array($wynik))
        {
            echo "<p>$rekord[0].$rekord[1], reżyseria: $rekord[2] $rekord[3]</p>";
        }
        mysqli_close($connect);
        ?>
        <!--skrypt 2
Działanie skryptu nr 2:
 Skrypt wysyła do bazy zapytanie 2
 W kolejnych akapitach wypisywane są rekordy w formacie: „<id>. <tytul>, reżyseria: <imie>
<nazwisko>”
-->
    </div>
    <div id="stopka">
    <p>Autor:0000000000000</p>
        <a href="kwerendy.txt">Zapytania do bazy</a>
        <a href="http://filmy.pl" target="_blank">Przejdź do filmy.pl</a>
    </div>
    </body>
</html>
