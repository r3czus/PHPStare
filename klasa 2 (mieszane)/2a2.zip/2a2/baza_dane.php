
<p>Wybierz wychowawcę</p>
<form action="" method="post">
<select name="wych">
<?php
    $connect=mysqli_connect("localhost","root","","szkola");
    $zapytanie="SELECT `id`, `imie`, `nazwisko` FROM `wychowawca` ";
    $wynik=mysqli_query($connect,$zapytanie);
    while($rekord=mysqli_fetch_array($wynik))
    {
       echo "<option value=$rekord[0]>$rekord[1] $rekord[2]</option>"; 
    }
    mysqli_close($connect);
?>
    </select>
    <input type="submit" value="sprawdz">
    </form>
<?php
if(isset($_POST['wych']))
{
    $id=$_POST['wych'];
    //echo $id;
    $connect=mysqli_connect("localhost","root","","szkola");
    $zapytanie="SELECT `nazwa`,wychowawca.imie,wychowawca.nazwisko FROM `klasa`,wychowawca where wychowawca.id='$id' AND wychowawca.id_klasy=klasa.id";
    $wynik=mysqli_query($connect,$zapytanie);
    if($rekord=mysqli_fetch_array($wynik))
    {
        echo "<p>Wychowawca $rekord[1] $rekord[2] ma klasę $rekord[0]";
    }
    mysqli_close($connect);
}
?>