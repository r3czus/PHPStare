<h1>Serwis ogłoszeniowy</h1>
<?php
//wypisz z tabeli ogloszenie tytul w h3 i tresc  w akapicie ogloszenia oraz odpowiadające im imie nazwisko email telefon pochylone z tabeli uzytkownik
$connect=mysqli_connect("localhost","root","","dane");
$zapytanie="SELECT `tytul`, `tresc`,imie,nazwisko,telefon,email From ogloszenie JOIN uzytkownik ON ogloszenie.uzytkownik_id=uzytkownik.id ";
$wynik=mysqli_query($connect,$zapytanie);
while($rekord=mysqli_fetch_array($wynik))
{
    echo "<h3>$rekord[0]</h3><p>$rekord[1]</p><em>$rekord[2] $rekord[3] $rekord[4]<strong>$rekord[5]</strong></em><hr>";
}
mysqli_close($connect);
?>
<form action="" method="post">
<select name="stanowisko">
<?php
//zrob liste rozwijana z nr stanowiska wypisz z tabeli pracownicy imie nazwisko pracownikow na danym stanowisku lista numerowana
$connect=mysqli_connect("localhost","root","","dane");
$zapytanie="SELECT DISTINCT `stanowisko` FROM `pracownicy` ";
$wynik=mysqli_query($connect,$zapytanie);
while($rekord=mysqli_fetch_array($wynik))
{
    echo "<option value='$rekord[0]'> $rekord[0]</option>";
}

?>
</select>
<input type="submit" value="sprawdz">
</form>
<ol>
<?php
if(isset($_POST['stanowisko']))
{
    $st=$_POST['stanowisko'];
    $zapytanie="SELECT `imie`, `nazwisko` FROM `pracownicy` WHERE `stanowisko` = '$st' ";
    $wynik=mysqli_query($connect,$zapytanie);
    while($rekord=mysqli_fetch_array($wynik))
    {
        echo "<li>$rekord[0] $rekord[1]</li>";
    }
}
mysqli_close($connect);
    ?>
    </ol>
<table border="2px solid black">
<tr><th>LP.</th><th>data</th><th>czas</th></tr>

<?php
//wypisz z tabeli wyniki datę i czas w tabelce, posortuj według czasu od najkrótszego
$connect=mysqli_connect("localhost","root","","dane");
$zapytanie="SELECT `wynik`, `dataUstanowienia` FROM `wyniki` ORDER BY `wynik` ASC ";
    $i=1;
$wynik=mysqli_query($connect,$zapytanie);
    while($rekord=mysqli_fetch_array($wynik))
    {
        
      echo "<tr><td>$i</td><td>$rekord[1]</td><td>$rekord[0]</td></tr>"; 
        $i++;
    }
mysqli_close($connect);
?>
    </table>
    