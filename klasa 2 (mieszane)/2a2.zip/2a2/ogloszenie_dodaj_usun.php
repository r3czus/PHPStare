<form action="nowy.php" method="post">
Podaj email
    <input type="email" name="email">
    <br>
Podaj telefon
    <input type="tel" name="telefon">
Podaj tytuł ogłoszenia
    <input type="text" name="tytul"><br>
Podaj tresc
    <textarea name="tresc" cols="40" rows="10"></textarea><br>
    <input type="submit" value="dodaj do bazy">
</form>
