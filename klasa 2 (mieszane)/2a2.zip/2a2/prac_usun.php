<form action="" method="post">

    <?php
    $connect=mysqli_connect("localhost","root","","baza");
    $zapytanie="SELECT id, `imie`, `nazwisko` FROM `pracownicy` ";
    $wynik=mysqli_query($connect,$zapytanie);
    while($rekord=mysqli_fetch_array($wynik))
    {
        echo "<input type='checkbox' name='prac[]' value='$rekord[0]'> $rekord[1] $rekord[2]<br>";
    }
    mysqli_close($connect);
    ?>
   
    <input type="submit" value="usuń">
</form>
<?php
if(isset($_POST['prac']))
{
    $id=$_POST['prac'];
    print_r($id);
    //echo $id;
    $zapytanie="";
    $connect=mysqli_connect("localhost","root","","baza");
    mysqli_query($connect,$zapytanie);
    mysqli_close($connect);
    //header("location:prac_usun.php");
}

?>