<h3>Wstaw ogloszenie do bazy</h3>
<form action="" method="post">

    <input type="submit" value="wstaw do bazy">
</form>
<?php



?>