<?php
$connect=mysqli_connect("localhost","root","","baza");
if(!empty($_POST['telefon']) && !empty($_POST['email']) &&
   !empty($_POST['tytul']) && !empty($_POST['tresc']))
{
    
    $connect=mysqli_connect("localhost","root","","baza");
    $telefon=$_POST['telefon'];
    $email=$_POST['email'];
    $zapytanie="SELECT id FROM uzytkownik WHERE telefon LIKE '$telefon' AND `email` LIKE '$email' ";
    $wynik=mysqli_query($connect,$zapytanie);
    if($rekord=mysqli_fetch_array($wynik))
      {
    $id_u=$rekord[0]; 
   $tytul=$_POST['tytul']; 
   $tresc=$_POST['tresc'];
   
    $zapytanie="INSERT INTO `ogloszenie` (`id`, `uzytkownik_id`, `kategoria`, `podkategoria`, `tytul`, `tresc`) VALUES (NULL, '$id_u', '2', '3', '$tytul', '$tresc');";
    mysqli_query($connect,$zapytanie);
        //wypisz ogloszenia tego uzytkownika
    }}
    $zapytanie="SELECT `tytul`, `tresc`,id FROM `ogloszenie` WHERE `uzytkownik_id` ='$id_u '";
    $wynik=mysqli_query($connect,$zapytanie);
    echo "<table border='2px solid black'>";
    while($rekord=mysqli_fetch_array($wynik)) 
    {
     echo "<tr><td><h3>$rekord[0]</h3><p>$rekord[1]</p></td><td><form method='post'><input type='submit' value='usuń'><input type='hidden' value='$rekord[2]'' name='usun'></form></td></tr>";   
    }
        
    echo "</table>";
        if(isset($_POST['usun']))
        {
            $id=$_POST['usun'];
            $zapytanie="DELETE FROM `ogloszenie` WHERE `ogloszenie`.`id` = '$id'";
            mysqli_query($connect,$zapytanie);
        }
    
    
    mysqli_close($connect);
    


?>